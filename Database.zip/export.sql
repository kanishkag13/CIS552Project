--------------------------------------------------------
--  File created - Wednesday-December-13-2023   
--------------------------------------------------------
@PRODUCTAVAILABILITY.sql
@PRODUCTINFO.sql
@P_PRODUCTAVAILABILITY.sql
@P_SALES.sql
@P_SUPPLIERINFO.sql
@SALES.sql
@SUPPLIERINFO.sql
--@PRODUCTAVAILABILITY_DATA_TABLE.json
--@PRODUCTINFO_DATA_TABLE.json
--@P_PRODUCTAVAILABILITY_DATA_TABLE.json
--@P_SALES_DATA_TABLE.json
--@P_SUPPLIERINFO_DATA_TABLE.json
--@SALES_DATA_TABLE.json
--@SUPPLIERINFO_DATA_TABLE.json
